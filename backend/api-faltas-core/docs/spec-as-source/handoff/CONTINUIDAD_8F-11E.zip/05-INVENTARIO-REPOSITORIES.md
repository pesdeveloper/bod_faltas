# Inventario de Repositories — 8F-11E

## Interfaces nuevas

| Interface | Operaciones clave |
|-----------|-------------------|
| VehiculoMarcaRepository | nextId, guardar, findById, findByCodigo, findByNombre, findAllActivas |
| VehiculoModeloRepository | nextId, guardar, findById, findByMarcaAndCodigo, findByMarcaAndNombre, findActivasByMarca |
| RubroVersionRepository | nextId, sincronizarAtomicamente, findByRubroId, findActualByIdRub, findAllActualesActivas, findByIdRub |
| ActaTransitoRepository | nextId, guardar, findByActaId, existsByActaId |
| ActaTransitoAlcohoemiaRepository | nextId, guardar, findById, findByActaId, findResultadoFinalByActaId, existsOrdenByActaId, marcarResultadoFinalAtomicamente |
| ActaVehiculoRepository | nextId, guardar, findByActaId, existsByActaId |
| ActaContravencionRepository | nextId, guardar, findByActaId, existsByActaId |
| ActaSustanciasAlimenticiasRepository | nextId, guardar, findByActaId, existsByActaId |
| ActaMedidaPreventivaRepository | nextId, guardar, findById, findByActaId, findActivasByActaId |

## Operaciones atómicas

| Repo | Método atómico | Mecanismo |
|------|----------------|-----------|
| InMemoryRubroVersionRepository | sincronizarAtomicamente() | synchronized block en store |
| InMemoryActaTransitoAlcohoemiaRepository | marcarResultadoFinalAtomicamente() | lockFinal object synchronized |
| InMemoryVehiculoMarcaRepository | (via VehiculoMarcaService.altaMarca) | synchronized method |
| InMemoryVehiculoModeloRepository | (via VehiculoModeloService.altaModelo) | synchronized method |