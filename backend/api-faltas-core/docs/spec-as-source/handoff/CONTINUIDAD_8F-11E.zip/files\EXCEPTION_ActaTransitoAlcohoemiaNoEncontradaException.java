package ar.gob.malvinas.faltas.core.domain.exception;
public class ActaTransitoAlcohoemiaNoEncontradaException extends RuntimeException {
    public ActaTransitoAlcohoemiaNoEncontradaException(Long id) { super("Medicion alcoholemia no encontrada: id=" + id); }
    public ActaTransitoAlcohoemiaNoEncontradaException(String msg) { super(msg); }
}
